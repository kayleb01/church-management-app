<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePeoplesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('peoples', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('avatar')->nullable();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('middle_name')->nullable();
            $table->string('email')->unique();
            $table->date('date_of_birth');
            $table->string('address');
            $table->string('state');
            $table->string('city');
            $table->integer('zipcode')->nullable();
            $table->smallInteger('gender');
            $table->string('mobile_number');
            $table->string('facebook')->nullable();
            $table->integer('group_id')->nullable();
            $table->string('job_title')->nullable();
            $table->string('employer')->nullable();
            $table->string('talent')->nullable();
            $table->string('school');
            $table->string('grade');
            $table->string('marital_status');
            $table->date('baptism_date')->nullable();
            $table->string('baptism_location')->nulllable();
            $table->date('join_date');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('peoples');
    }
}
