<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Auth::routes();
Route::get('/', 'dashboardController@index')->name('/')->middleware('auth');
Route::get('/registered', 'Auth\RegisterController@registered');



Route::get('/new/people', 'dashboardController@userNew')->name('/new/people');
Route::get('/people', 'PeopleController@index');
Route::get('/peoples', 'PeopleController@show');
Route::delete('people/{id}', 'PeopleController@destroy');
Route::post('/people/add', 'PeopleController@store');
Route::patch('/people/{id}/update', 'PeopleController@update');



Route::get('users/', 'adminUserController@users')->name('/users');
Route::get('userdata', 'adminUserController@index');
Route::get('user/', 'dashboardController@user')->name('/user');
Route::delete('user/{id}', 'adminUserController@destroy');
Route::post('/admin/adduser', 'adminUserController@create');
Route::patch('/admin/{id}/adduser', 'adminUserController@update');

 Route::get('events/', 'dashboardController@events');
 
 Route::get('view/group', 'groupController@index');
 Route::get('/groups', 'GroupController@show');
 Route::post('/group/add', 'GroupController@store');
 Route::patch('/group/{id}/edit', 'GroupController@update');
 Route::delete('/group/{id}', 'GroupController@destroy');

Route::get('/events', 'dashboardController@events')->name('/events');
Route::get('/new/event', 'dashboardController@newEvent');

Route::get('/view/contribution', 'dashboardController@contribution');
Route::get('/new/contribution', 'dashboardController@Addcontri');

Route::get('/followup', 'dashboardController@followup');
Route::get('/followup/add', 'dashboardController@followupAdd');

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/form', 'dashboardController@form');


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
