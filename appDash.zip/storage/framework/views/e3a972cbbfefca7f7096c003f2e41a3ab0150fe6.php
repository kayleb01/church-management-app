<?php $__env->startSection('content'); ?>

<div class="container bg-gray">
	<div class="row">
		<div class="col-md-9 col-lg-9">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="/sales">Back to Sales</a></li>
			</ol>
			<div class="card card-body shadow">
				<h3>Available Stock</h3>
				<table class="table table-striped">
					<thead>
						<tr>
							
						</tr>
							<th>Product</th> 
							<th>Quantity</th>
							<th>Cost Price</th>
							<th>Selling Price</th>
							<th>Action</th>

					</thead>
					<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($stock->description); ?></td>
							<td><?php echo e($stock->quantity); ?></td>
							<td><?php echo e($stock->costPrice); ?></td>
							<td><?php echo e($stock->sellingPrice); ?></td>
							<td><a href="#">edit</a>|<a href="#" class="text-danger">del</a></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


				</table>
				<span class="mt-3"><?php echo e($stocks->links()); ?></span>
			</div>

			
		</div>
		
			<?php echo $__env->make('_partials._widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara\resources\views/moderatePrice.blade.php ENDPATH**/ ?>