<?php $__env->startSection('content'); ?>

<div class="container bg-gray">
	<div class="row">
		<div class="col-md-9 col-lg-9">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="/sales">Back to Sales</a></li>
			</ol>
			<div class="card card-body shadow">
				<h3>Book Credit</h3>
				<?php if(session('success')): ?>
					<div class="alert alert-success"><?php echo e(session('success')); ?></div>
				<?php endif; ?>
				<?php if(session('error')): ?>
					<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
				<?php endif; ?>
				<form method="post" action="/makeCredit">
					<select class="form-control rounded-pill mb-2" name="description" required>
						<option value=""> Select Product </option>
						<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($stock->id); ?>"><?php echo e($stock->description); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<input type="number" class="form-control mb-2 rounded-pill" placeholder="Select Quantity" name="quantity" id="quantity" required>
					<input type="text" name="debtor" class="form-control rounded-pill mb-2" placeholder="Debtor" required>
					<?php echo e(csrf_field()); ?>

					<button type="submit" name="submit" class="btn btn-secondary btn-block p-2 rounded-pill"> Submit</button>
				</form>
			</div>
		</div>
		
			<?php echo $__env->make('_partials._widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara\resources\views/bookCredit.blade.php ENDPATH**/ ?>