<?php $__env->startSection('content'); ?>

<div class="container bg-gray">
	<div class="row">
		<div class="col-md-9 col-lg-9">
			<div class="card card-body shadow">
				<h3>Today's Sales sofar..</h3>
				<table class="table table-striped">
					<thead>
						<tr>
							
						</tr>
							<th>Product</th> 
							<th>Quantity</th>
							<th>Price</th>
					</thead>
					<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
					<tr>
						<td >
							<?php echo $sale->stock->description; ?>

						</td>
						<td>
							<?php echo e($sale->quantity); ?>

						</td>
						<td>
							<?php echo e($sale->stock->sellingPrice); ?>

						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
				</table>
			</div>

			<div class="panel panel-body m-2 p-3 bg-light" style="border: 1px #ccc solid;">
				<h3>SALES</h3>
				<?php if(session('success')): ?>
					<div class="alert alert-success"><?php echo e(session('success')); ?></div>
				<?php endif; ?>
				<?php if(session('error')): ?>
					<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
				<?php endif; ?>
				<form method="POST" action="/makeSales">
					<?php echo e(csrf_field()); ?>

					<select class="form-control rounded-pill mb-2" name="product_id" required>
						<option value=""> Select Product </option>
						<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($stock->id); ?>"><?php echo e($stock->description); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<input type="number" class="form-control mb-2 rounded-pill" placeholder="Select Quantity" name="quantity" id="quantity" required>
					<button name="add" class="btn btn-outline-secondary rounded-pill float-right mb-4 px-4">Add</button>
					<button type="submit" name="submit" class="btn btn-secondary btn-block p-2 rounded-pill"> Submit</button>
				</form>
				
			</div>
		</div>
		
			<?php echo $__env->make('_partials._widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara\resources\views/sales.blade.php ENDPATH**/ ?>