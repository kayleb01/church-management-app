<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- CSRF Token -->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<title>Admin panel</title>
<meta name="description" content=" ">
<link rel="stylesheet" href="<?php echo e(url('css/core.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('css/custom.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">

<!-- <link rel="stylesheet" href="<?php echo e(url('css/skin-red-light.css')); ?>"> -->
<link rel="icon" href="<?php echo e(url('flav.png')); ?>">
<link href="<?php echo e(url('css/font-awesome.min.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(url('css/skin-red-light.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('css/app.css')); ?>">
<script src="<?php echo e(url('js/Popper.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(url('js/jquery-2.2.3.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('js/custom.js')); ?>" type="text/javascript"></script>
<script>
        window.App = <?php echo json_encode([
            'csrfToken' => csrf_token(),
            'user' => Auth::user(),
            'signedIn' => Auth::check()
        ]); ?>;
    </script>
</head>
<body class="skin-red-light sidebar-mini">
<div id="app">
    <header class="main-header">
        <!-- Logo -->
        <a href="<?php echo e(route('/')); ?>" class="logo">
            <!-- mini logo for sidebar mini 50x50 pixels -->
            <span class="logo-mini">CHM</span>
            <!-- logo for regular state and mobile devices -->
            <span class="">CHMeetings</span>
        </a>
        <nav class="navbar navbar-static-top p-0" role="navigation">
            <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                <span class="sr-only">Toggle navigation</span>
            </a>
        </nav>
        </header>
        <?php echo $__env->make('_partials._widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>   
            
        <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
</div> <!--Closing tag of id#app -->
        <?php echo $__env->yieldContent('scripts'); ?>
     <script src="<?php echo e(url('js/app.js')); ?>"></script>
    <script src="/js/scripts.js"></script>
    <script src="/js/app_admin.js"></script>
   

</body>
</html>
<?php /**PATH C:\xampp\htdocs\appDash\resources\views/layouts/app.blade.php ENDPATH**/ ?>