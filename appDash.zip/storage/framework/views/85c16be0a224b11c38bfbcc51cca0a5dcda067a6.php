<?php $__env->startSection('content'); ?>
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-12 mb-2">
		<section class="content-header">
    		<Addfollowup></Addfollowup>
    	</section>
	</div>
  
	<section class="content mt-2">
			<div class="card">
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Responsible</th>
                      <th>Date</th>
                      <th>Notes</th>
					  <th>Action</th>
					  <th>Type</th>
					  <th>Status</th>
					  <th></th>
					  <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Caleb</td>
                      <td>John Doe</td>
                      <td>11-7-2014</td>
                      <td></td>
					  <td></td>
					  <td>Visit</td>
					  <td>pending</td>
					  <td><button class="border border-secondary"> <i class="fa fa-check"></i></button></td>
					  <td><a href="#"> <i class="fa fa-edit"></i></a> | <a href="#"><i class="fa fa-trash"></i></a></td>
					</tr>
					
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
	
            
	</section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appDash\resources\views/dashboard/followup.blade.php ENDPATH**/ ?>