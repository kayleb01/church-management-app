<?php $__env->startSection('content'); ?>
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-12 col-sm-12">
		<section class="content-header">
    		<Addpeople :groups="<?php echo e($groups); ?>"></Addpeople>
  		</section>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appDash\resources\views/dashboard/people.blade.php ENDPATH**/ ?>