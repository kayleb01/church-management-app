<?php $__env->startSection('content'); ?>
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-11 col-sm-12">
		<section class="content-header">
    		<Addpeople></Addpeople>
  		</section>
<section class="content">
	      <ul class="list-group">
	      	<li class="list-group-item">
	      		<div class="dropdown pull-right">
					<a class="dropdown-toggle btn btn-default p-0" data-toggle="dropdown" href="#" aria-expanded="true">
					</a>
					<ul class="dropdown-menu p-2">
						<li role="presentation">
                        
						    <a role="menuitem" tabindex="-1" target="_blank" href="<?php echo e(url('new/user/')); ?>">Add Person</a>
						</li>
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" href="<?php echo e(url('group/edit')); ?>">Edit</a>
						</li>
					
						<li role="presentation" class="divider"></li>
						<li role="presentation" class="text-danger">
                      
						    <a href="#" onclick="event.preventDefault(); document.getElementById('delete_form').submit()" class="text-danger">Delete</a>
						    <form id="delete_form" method="POST" action="" style="display: none;"><input type="hidden" name="_method" value="delete">
						    	
							<?php echo e(csrf_field()); ?></form>
						</li>
					</ul>
				</div>
                <img src="<?php echo e(url('/storage/face-1.jpg')); ?>" alt="" class="image-circle">
	      		<a href="#" class="link">Covenant Adeniyi</a> <br>
	      		0701 346 7998
	      		
	      	</li>
	      	<li class="list-group-item">
	      		<div class="dropdown pull-right">
					<a class="dropdown-toggle btn btn-default p-0" data-toggle="dropdown" href="#" aria-expanded="true">
						<!-- <i class="fa fa-bars"></i> -->
					</a>
					<ul class="dropdown-menu p-2">
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" target="_blank" href="<?php echo e(url('new/user/')); ?>">Add Person</a>
						</li>
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" href="<?php echo e(url('group/edit')); ?>">Edit</a>
						</li>
					
						<li role="presentation" class="divider"></li>
						<li role="presentation">
						    <a href="#" onclick="event.preventDefault(); document.getElementById('delete_form').submit()" class="text-danger">Delete</a>
						    <form id="delete_form" method="POST" action="" style="display: none;"><input type="hidden" name="_method" value="delete">
						    	
							<?php echo e(csrf_field()); ?></form>
						</li>
					</ul>
				</div>
                <img src="<?php echo e(url('/storage/face-1.jpg')); ?>" alt="" class="image-circle">
	      		<a href="#" class="link">
	      			Sunday Emmanuel</a><br>
	      			090 875 6733
	      	</li>
	      	<li class="list-group-item">
	      		<div class="dropdown pull-right">
					<a class="dropdown-toggle btn btn-default p-0" data-toggle="dropdown" href="#" aria-expanded="true">
						<!-- <i class="fa fa-bars"></i> -->
					</a>
					<ul class="dropdown-menu p-2">
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" target="_blank" href="<?php echo e(url('new/user')); ?>">Add Person</a>
						</li>
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" href="<?php echo e(url('group/edit')); ?>">Edit </a>
						</li>
					
						<li role="presentation" class="divider"></li>
						<li role="presentation">
						    <a href="#" onclick="event.preventDefault(); document.getElementById('delete_form').submit()"  class="text-danger link">Delete user</a>
						    <form id="delete_form" method="POST" action="" style="display: none;"><input type="hidden" name="_method" value="delete">
						    	
							<?php echo e(csrf_field()); ?></form>
						</li>
					</ul>
				</div>
                <img src="<?php echo e(url('/storage/face-1.jpg')); ?>" alt="" class="image-circle">
	      		<a href="#">Adewale Ibrahim</a><br>
	      		0802 356 4675
	      	</li>
	      </ul>
		</section>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\appDash\resources\views/dashboard/people.blade.php ENDPATH**/ ?>