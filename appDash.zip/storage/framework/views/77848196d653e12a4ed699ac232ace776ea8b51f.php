<footer class="main-footer">
    <div class="container">
        <div class="hidden-xs">
            <center>&copy; <?=date('Y')?></center>
        </div>
    </div>
</footer>
</div> 
 <script src="<?php echo e(url('js/scripts.js')); ?>"></script>
 <script src="<?php echo e(url('js/jquery-2.2.3.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\appDash\resources\views/layouts/footer.blade.php ENDPATH**/ ?>