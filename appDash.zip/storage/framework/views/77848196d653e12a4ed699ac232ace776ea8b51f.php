<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2020 
  </footer>
</div>
<!-- ./wrapper -->
<!-- scripts -->
<script src="<?php echo e(url('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appDash\resources\views/layouts/footer.blade.php ENDPATH**/ ?>