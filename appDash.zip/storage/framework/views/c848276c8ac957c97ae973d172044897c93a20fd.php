<!DOCTYPE html>
<html>
<head>
    <title>Laraspace - Laravel Admin</title>
    <link href='https://fonts.googleapis.com/css?family=Roboto:400,300,700' rel='stylesheet' type='text/css'>
    <script src="<?php echo e(asset('/js/core/pace.js')); ?>"></script>
    <link href="<?php echo e(mix('/css/laraspace.css')); ?>" rel="stylesheet" type="text/css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <?php echo $__env->make('admin.layouts.partials.favicons', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
</head>
<body class="layout-default skin-default">
    <?php echo $__env->make('_partials.laraspace-notifs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="app" class="site-wrapper">
        <?php echo $__env->make('_partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="mobile-menu-overlay"></div>
        <?php echo $__env->make('_partials.sidebar',['type' => 'default'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('_partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>

    <script src="<?php echo e(mix('/js/core/plugins.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/demo/skintools.js')); ?>"></script>
    <script src="<?php echo e(mix('/js/core/app.js')); ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\appDash\resources\views/layouts/layout-basic.blade.php ENDPATH**/ ?>