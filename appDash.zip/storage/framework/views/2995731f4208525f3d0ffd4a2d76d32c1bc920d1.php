<?php $__env->startSection('content'); ?>

<div class="container bg-gray">
	<div class="row">
		<div class="col-md-9 col-lg-9">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="/sales">Back to Sales</a></li>
			</ol>
			<div class="card card-body mt-2 shadow">
				<span class="btn "> <a href="#stock" class="btn-flat float-right">Skip to Add Stock</a> </span>
				<h4>Available Products</h4>
				<table class="table table-striped">
					<thead>
						<tr>
							<th>Product</th>
							<th>Quantity</th>
							<th>Price</th>
						</tr>
					</thead>
					
						<?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stocks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						<td><?php echo e($stocks->description); ?></td>
						<td><?php echo e($stocks->quantity); ?></td>
						<td><?php echo e($stocks->sellingPrice); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($stock->links()); ?>

				</table>

			</div>
			<div class="panel panel-body m-3 p-3" style="border: 1px #ccc solid; background-color: #ccc" id="stock">
				<h3>Add Stock</h3>
				<?php if(session('success')): ?>
					<div class="alert alert-success"><?php echo e(session('success')); ?></div>
				<?php endif; ?>
				<?php if(session('error')): ?>
					<div class="alert alert-danger"><?php echo e(session('error')); ?></div>
				<?php endif; ?>
				<form method="POST" action="<?php echo e(route('addProduct')); ?>">
					<?php echo e(csrf_field()); ?>

					<input type="text" name="description" class="form-control rounded-pill mt-3 mb-2" placeholder="Description" required>
					 <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                     <?php endif; ?>  
					<input type="text" class="form-control mb-2 rounded-pill" placeholder="Cost Price" name="costPrice" required>
					 <?php if($errors->has('costPrice')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('costPrice')); ?></strong>
                        </span>
                     <?php endif; ?>  
					<input type="text" name="sellingPrice" class="form-control rounded-pill mb-2" placeholder="Selling Price" required>
					 <?php if($errors->has('sellingPrice')): ?>
                        <span class="help-block">
                         <strong><?php echo e($errors->first('sellingPrice')); ?></strong>
                        </span>
                     <?php endif; ?>  
					<input type="number" name="quantity" class="form-control rounded-pill mb-4" placeholder="Quantity" required>
					 <?php if($errors->has('quantity')): ?>
                        <span class="help-block">
                            <strong><?php echo e($errors->first('quantity')); ?></strong>
                        </span>
                     <?php endif; ?>  
					<input type="submit" name="submit" class="btn btn-block btn-secondary rounded-pill">
				</form>
				
			</div>
		</div>
			<?php echo $__env->make('_partials._widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Lara\resources\views/AddProduct.blade.php ENDPATH**/ ?>