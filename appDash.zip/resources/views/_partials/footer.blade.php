<footer class="site-footer">
    <div class="text-right">
      Powered by <a href="http://bytefury.com" target="_blank">Bytefury</a>
    </div>
</footer>
