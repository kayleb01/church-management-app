<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2020 
  </footer>
</div>
<!-- ./wrapper -->
<!-- scripts -->
<script src="{{url('js/app.js')}}"></script>
</body>
</html>
