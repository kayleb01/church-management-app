<footer class="main-footer">
    <div class="container">
        <div class="hidden-xs">
            <center>&copy; <?=date('Y')?></center>
        </div>
    </div>
</footer>
</div> 
 <script src="{{url('js/scripts.js')}}"></script>
 <script src="{{url('js/jquery-2.2.3.js')}}"></script>
</body>
</html>