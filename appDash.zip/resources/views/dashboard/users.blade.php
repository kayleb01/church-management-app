@extends('layouts.app')
@section('content')
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-11 col-sm-12">
		<section class="content-header">
    		<Adduser></Adduser>
  		</section>
		<section class="content">
		<div class="dropdown pull-right btn btn-primary py-2 px-3 mb-2" >
					<a class="dropdown-toggle btn btn-default p-0" data-toggle="dropdown" href="#" aria-expanded="true">
					Bulk Actions</a>
					<ul class="dropdown-menu p-2">
						<li role="presentation">
                        
						    <a role="menuitem" tabindex="-1" target="_blank" href="{{url('new/user/')}}">Add Person</a>
						</li>
						<li role="presentation">
						    <a role="menuitem" tabindex="-1" href="{{url('group/edit')}}">Edit</a>
						</li>
					
						<li role="presentation" class="divider"></li>
						<li role="presentation" class="text-danger">
                      
						    <a href="#" onclick="event.preventDefault(); document.getElementById('delete_form').submit()" class="text-danger">Delete</a>
						    <form id="delete_form" method="POST" action="" style="display: none;"><input type="hidden" name="_method" value="delete">
						    	
							{{csrf_field()}}</form>
						</li>
					</ul>
				</div>
		<table class="table table-hover bg-light">
			<th><input type="checkbox" name="mark" id="mark"></th>
			<th>NAME</th>
			<th>USERNAME</th>
			<th>MOBILE NUMBER</th>
			<th>EMAIL</th>
			<th>ROLE</th>
			<th>LAST ACCE...</th>
			<tr>
				<td><input type="checkbox" name="mark" id="mark"></td>
				<td><a href="/user">  <img src="{{url('/storage/face-1.jpg')}}" alt="" class="image-circle"> Caleb Bala</a></td>
				<td>mail@mail.com</td>
				<td> 08097622341</td>
				<td>mail@mail.com</td>
				<td>user</td>
				<td>21/05/2020</td>
			</tr>
			<tr>
				<td><input type="checkbox" name="mark" id="mark"></td>
				<td><a href="/ser">  <img src="{{url('/storage/face-1.jpg')}}" alt="" class="image-circle"> Ibrahim Akawu</a></td>
				<td>mail@mail.com</td>
				<td> 09067622341</td>
				<td>mail@mail.com</td>
				<td>Owner</td>
				<td>21/05/2020</td>
			</tr>
		</table>
		</section>
	</div>
</div>
@endsection