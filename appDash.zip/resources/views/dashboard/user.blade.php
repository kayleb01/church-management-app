@extends('layouts.app')

@section('content')
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-12 col-sm-12 mb-5">
		<section class="content-header">
    		<Addevent></Addevent>
  		</section>
  	</div>
	<section class="content">
		<div class="container">
            <div class="row no-gutter">
                <div class="col-md-6">
					<div class="d-flex justify-content-center">
						<img src="{{url('/storage/face-1.jpg')}}" alt="User Image" class="image-user">
					</div>
					<div class="d-flex justify-content-center mt-2">
						<button class="btn btn-default rounded-circle m-1" id="btn-bell"><i class="fa fa-bell"></i></button>
						<button class="btn btn-default rounded-circle m-1" id="btn-bell"><i class="fa fa-qrcode"></i></button>
					</div>
					<div class="card p-0">
						<div class="card-body row p-2">
							<div class="col-md-4 text-center">
								<b>Birthday</b><br>
								<span>29 May </span>		
							</div>
							<div class="col-md-4">
								<b>Gender</b> <br>
								<span>Male</span>		
							</div>
						</div>
					</div>
					<div class="card p-0 mt-4">
						<div class="card-body row p-2">
							<div class="col-md-4 text-center">
								<b>School</b><br>
								<span>____ </span>		
							</div>
							<div class="col-md-4">
								<b>Grade</b> <br>
								<span>____</span>		
							</div>
						</div>
					</div>
					<div class="card p-0 mt-4">
						<div class="card-body row p-2">
							<div class="col-md-4 text-center">
								<b>Baptism Date</b><br>
								<span>____ </span>		
							</div>
							<div class="col-md-4">
								<b>Baptism Location</b> <br>
								<span>____</span>		
							</div>
						</div>
					</div>
				</div>
                <div class="col-md-6">
					<div class="card p-0 mt-4">
						<div class="card-body row p-2">
							<div class="col-md-4 text-center">
								<b>Mobile Phone</b><br>
								<span>____ </span>		
							</div>
							<div class="col-md-4 col-sm-6">
								<b>Home Phone</b> <br>
								<span>____</span>		
							</div>
							<div class="col-md-4 col-sm-6">
								<b>Email</b> <br>
								<span>Mail@mailme.com</span>		
							</div>
						</div>
					</div>
					
				</div>
            </div>
        </div>
    </section>
</div>
@endsection