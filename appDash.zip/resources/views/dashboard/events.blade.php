@extends('layouts.app')

@section('content')
<div style="min-height: 822px;" class="content-wrapper">
	<div class="col-md-12 col-sm-12 mb-5">
		<section class="content-header">
    		<Addevent></Addevent>
  		</section>
  	</div>
	<section class="content">
		<div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Upcoming events in 30 days</h3> <span><a href="#" class="pull-right link">View all</a></span>
            </div>
            <div class="box-body">
                <p>
            
                </p>
            </div>
        </div>
    </section>
</div>
@endsection
