<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Group;
use App\People;

class PeopleController extends Controller
{
 /**
     * Display a listing of the people.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $groups = Group::get();
        return view('dashboard.people', compact('groups'));
        
    }

    /**
     * Store a newly created people in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'first_name' => 'required',
            'last_name' => 'required',
            'middle_name'  => 'sometimes',
            'email' => 'required|unique:peoples',
            'date_of_birth'  => 'required',
            'address' => 'required',
            'state' => 'required',
            'city' => 'required',
            'zipcode' => 'sometimes',
            'gender' => 'required',
            'mobile_number'  => 'required',
            'facebook' => 'sometimes',
            'group_id'  => 'sometimes',
            'job_title' => 'sometimes',
            'employer'  => 'sometimes',
            'talent'  => 'sometimes',
            'school'  => 'required',
            'grade' => 'required',
            'marital_status' => 'required',
            'baptism_date'  => 'sometimes',
            'baptism_location'  => 'sometimes',
            'join_date' => 'required' 
        ]); 

        return  People::create([
            'first_name' => request('first_name'),
            'last_name' => request('last_name'),
            'middle_name'  => request('middle_name'),
            'email'      => request('email'),
            'date_of_birth'  => request('date_of_birth'),
            'address' => request('address'),
            'state' => request('state'),
            'city' => request('city'),
            'zipcode' => request('zipcode'),
            'gender' => request('gender'),
            'mobile_number'  => request('mobile_number'),
            'facebook' => request('facebook'),
            'group_id'  => 1,
            'job_title' => request('job_title'),
            'employer'  => request('employer'),
            'talent'  => request('talent'),
            'school'  => request('school'),
            'grade' => request('grade'),
            'marital_status' => request('marital_status'),
            'baptism_date'  => request('baptism_date'),
            'baptism_location'  => request('baptism_location'),
            'join_date' => request('join_date')
        ]);
    }

    /**
     * Display the specified people.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        return People::paginate(20);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, People $id)
    {
                //$this->authorize('update', $thread);
    $this->validate($request,[
        'first_name' => 'required',
        'last_name' => 'required',
        'middle_name'  => 'sometimes',
        'email' => 'required|unique:peoples',
        'date_of_birth'  => 'required',
        'address' => 'required',
        'state' => 'required',
        'city' => 'required',
        'zipcode' => 'sometimes',
        'gender' => 'required',
        'mobile_number'  => 'required',
        'facebook' => 'sometimes',
        'group_id'  => 'required',
        'job_title' => 'sometimes',
        'employer'  => 'sometimes',
        'talent'  => 'sometimes',
        'school'  => 'required',
        'grade' => 'required',
        'marital_status' => 'required',
        'baptism_date'  => 'sometimes',
        'baptism_location'  => 'sometimes',
        'join_date' => 'required' 
    ]);
    $update = $id->update($request->all());
    if($update){
        return ['message' => 'person updated successfully'];
    }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(People $id)
    {
        $people =  $id;
        $people->delete();

        if (request()->expectsJson()) {
            return response(['status' => 'Group deleted']);
        }

        return back();
    }
    
}
